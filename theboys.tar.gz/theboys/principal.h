// Includes de todo o projeto
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

// Defines de todo o projeto

/*
    Path: trabalho-grande/principal.h
    Funções da principal.c"
*/

/* Funções de manipulação principais do projeto */
int gerar_aleatorio (int min, int max);
double distancia_pontos (int A, int B, int X, int Y);
float media (int A, int B);